let scoopAmount = document.getElementsByClassName('scoopAmount').defaultValue = 1;
let cAmount = document.getElementsByClassName('cAmount').defaultValue = 2;
//let CurrencyType = document.getElementById('currency');
const btn = document.getElementById('btn');

// console.log(scoopAmount);
// console.log(cAmount);

// function getData(form) {
//   var formData = new FormData(form);

//   for (var pair of formData.entries()) {
//     console.log(pair[0] + ": " + pair[1]);
//   }

//   console.log(Object.fromEntries(formData));
// }
// document.getElementById("buy-Form").addEventListener("confirm", function (e) {
//   e.preventDefault();
//   getData(e.target);
// });

paypal
  .Buttons({
    createOrder: function () {
      return fetch("/create-order", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        
        body: JSON.stringify({
          
          items: [
            {
              id: scoopAmount,
              quantity: cAmount,
            },
          ],
        }),
      })
        .then(res => {
          if (res.ok) return res.json()
          return res.json().then(json => Promise.reject(json))
        })
        .then(({ id }) => {
          return id
        })
        .catch(e => {
          console.error(e.error)
        })
    },
    onApprove: function (data, actions) {
      return actions.order.capture().then(function (details) {
        alert("Transaction Completed by: " + details.payer.name.given_name)
      })
    },
  })
  .render("#paypal")
